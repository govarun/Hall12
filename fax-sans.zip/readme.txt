For the quality of Fax sans series, we are sharing the first beta version. ☺
We are just letting you know a few things since it is a font we are developing with hard efforts.
 
1
You cannot use it for commercial purposes without the agreement of Fax.
Please contact [ collabo@f-a-x.website ] for the commercial inquiries.
 
2-1
Although the first plan/design of Fax sans series are completed, it is an OTF file for the beta version that the contents of detail upgrades including the typography coding, some special characters, and automatic kerning, are not applied.
 
2-2
Anyone can download and redistribute it, but I want you to refrain from editing even for the personal uses.
( Fax want it to be used as we intended. If needed, we will upgrade it. )
​
3-1
To the people who contact [ hello@f-a-x.website ] while using the beta version of [ Fax sans-beta ], and help us by
giving the information of purposes of use about industry field and reasonable/developmental feedbacks, 
we will be plan to share the final OTF font in the future through personal emails used in the inquiry.
 
3-2
We do not particularly save the personal emails that were sent as feedbacks, and do not use it for business purposes. 
( It is only for the prevention of illegal downloads and immoral actions. )
​
​

